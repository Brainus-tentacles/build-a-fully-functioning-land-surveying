@echo off
title GeoSurvey Pro - Android Field App
echo Starting GeoSurvey Pro Android Field App...
python -m http.server 8080 || py -m http.server 8080
start http://localhost:8080/
pause
