@echo off
title GeoSurvey Pro - Android Field App
echo Starting GeoSurvey Pro Android Field App...
python -m http.server 8080 || py -m http.server 8080 || node -e "require('http').createServer((req,res)=>{const fs=require('fs');const p=req.url==='/'?'index.html':req.url.slice(1);if(fs.existsSync(p)){res.writeHead(200);fs.createReadStream(p).pipe(res);}else{res.writeHead(404);res.end();}}).listen(8080);console.log('Server on 8080');"
start http://localhost:8080/
pause
