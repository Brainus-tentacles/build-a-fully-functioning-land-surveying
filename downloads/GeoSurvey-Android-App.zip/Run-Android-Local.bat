@echo off
title GeoSurvey Pro - Android Field App
echo ========================================================
echo Starting GeoSurvey Pro Android Field App...
echo ========================================================
if exist "GeoSurvey-Android-Standalone.html" (
    start "" "GeoSurvey-Android-Standalone.html"
) else (
    start "" "index.html"
)
