#!/bin/bash
echo "Starting GeoSurvey Pro Android Field App on http://localhost:8080..."
python3 -m http.server 8080 &
SERVER_PID=
sleep 1
if which xdg-open > /dev/null; then
  xdg-open http://localhost:8080/
elif which open > /dev/null; then
  open http://localhost:8080/
fi
wait 
