#!/bin/bash
echo "Starting GeoSurvey Pro Android Field App..."
if [ -f "GeoSurvey-Android-Standalone.html" ]; then
    TARGET="GeoSurvey-Android-Standalone.html"
else
    TARGET="index.html"
fi
if which xdg-open > /dev/null 2>&1; then
    xdg-open "$TARGET"
elif which open > /dev/null 2>&1; then
    open "$TARGET"
else
    python3 -m http.server 8080
fi
