======================================================================
GEOSURVEY PRO - ANDROID FIELD APP (TESTING PACKAGE)
======================================================================

FOR ANDROID PHONES & TOPCON/SOKKIA RUGGED TABLETS (FC-6000 / SHC6000)

WAYS TO RUN & TEST:
1. Double-click 'GeoSurvey-Android-Standalone.html':
   Runs immediately in any browser offline with NO server and NO setup!

2. Direct 1-Tap Web Install (Easiest on Android):
   Open in Chrome on Android:
   https://antigravity.luch.dev/site/aef3fa0e-ec18-4035-be15-3b34365d52dc/52aed9997b990f4c7798e12e/android.html
   Tap "Install App" or menu (⋮) -> "Add to Home Screen".
   Installs as a native APK-like full-screen app with the JSI Kissimmee icon!

3. Run with local server:
   Windows: Double-click 'Run-Android-Local.bat'.
   Mac/Linux: Run 'sh Run-Android-Local.sh'.
