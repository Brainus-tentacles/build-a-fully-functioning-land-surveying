======================================================================
GEOSURVEY PRO - ANDROID FIELD APP (TESTING PACKAGE)
======================================================================

FOR ANDROID PHONES & TOPCON/SOKKIA RUGGED TABLETS (FC-6000 / SHC6000)

HOW TO TEST:
Method 1: Direct Web Link (Easiest on your phone)
  1. Open Chrome on your Android device.
  2. Visit: https://antigravity.luch.dev/site/aef3fa0e-ec18-4035-be15-3b34365d52dc/52aed9997b990f4c7798e12e/android.html
  3. Tap the three dots (menu) in Chrome -> "Add to Home Screen" or "Install App".
  4. The app installs with the JSI Kissimmee icon and runs full-screen offline!

Method 2: Test Locally from this ZIP on PC/Mac
  - On Windows: Double-click 'Run-Android-Local.bat' or open 'index.html'.
  - On Mac/Linux: Run 'sh Run-Android-Local.sh' or open 'index.html'.

TESTING CHECKLIST FOR FIELD CREWS:
[ ] 1. RTK GPS & Shots: Tap '+ Shot' or '🛰️ GPS' to record survey points.
[ ] 2. Split Screen: View 3/4 survey canvas and 1/4 AIM Field Chat simultaneously.
[ ] 3. 2-Person Chat: Send shot coordinates (📍 Send Pt) or linework (💬 Send CAD) to Civil 3D drafter Dave.
[ ] 4. Field Book: Check the 2-page yellow Transit & Level book loop closure arithmetic check.
[ ] 5. Raw File (.RW5): Export Topcon/Sokkia MAGNET Field raw file.

Thank you for testing!
