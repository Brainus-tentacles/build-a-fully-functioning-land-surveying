// Simplistic Land Surveying Linework & Field Drawing Engine
// Clean, touch-friendly linework tool for boundary, road, utilities & buildings with DXF upload/download
class CadEngine {
  constructor(canvasId) {
    this.canvas = document.getElementById(canvasId);
    this.ctx = this.canvas ? this.canvas.getContext('2d') : null;

    // Viewport transform (World: Northing, Easting in survey feet)
    this.originN = 10250.0;
    this.originE = 10250.0;
    this.scale = 1.0;
    this.minScale = 0.05;
    this.maxScale = 30.0;

    // Interaction states
    this.isPanning = false;
    this.lastMouseX = 0;
    this.lastMouseY = 0;
    this.activeTool = 'line'; // 'line', 'point', 'measure', 'pan', 'select'
    this.currentFeature = 'BOUNDARY'; // 'BOUNDARY', 'CENTERLINE', 'EOP_CURB', 'BUILDING', 'UTILITIES'

    // Snapping
    this.snapRadius = 22; // pixels
    this.snappedPoint = null;

    // Active linework vertices
    this.activeVertices = [];
    this.mouseWorldN = 10250.0;
    this.mouseWorldE = 10250.0;
    this.cursorScreenX = 0;
    this.cursorScreenY = 0;

    // Survey Feature Definitions
    this.features = {
      BOUNDARY: { name: "Boundary", c3d: "V-PROP-LINE", color: "#ef4444", lineWidth: 2.5, closed: true, dash: [] },
      CENTERLINE: { name: "Road Centerline", c3d: "V-ROAD-CNTR", color: "#eab308", lineWidth: 2.0, closed: false, dash: [8, 4] },
      EOP_CURB: { name: "Edge of Pavement", c3d: "V-ROAD-CURB", color: "#94a3b8", lineWidth: 1.8, closed: false, dash: [] },
      BUILDING: { name: "Building Footprint", c3d: "V-BLDG", color: "#a855f7", lineWidth: 2.0, closed: true, dash: [] },
      UTILITIES: { name: "Utilities / SUE", c3d: "V-UTIL-WATR", color: "#0284c7", lineWidth: 2.0, closed: false, dash: [12, 4] },
      FIELD_SKETCHES: { name: "Fence / Sketch", c3d: "V-SITE-FENC", color: "#f97316", lineWidth: 1.5, closed: false, dash: [] },
      SKETCH: { name: "Field Sketch", c3d: "V-SITE-FENC", color: "#f97316", lineWidth: 1.5, closed: false, dash: [] }
    };

    // Layer visibility (paired with Autodesk Civil 3D NCS Layers)
    this.layers = {
      BOUNDARY: { name: "Boundary (Red)", c3d: "V-PROP-LINE", color: "#ef4444", visible: true },
      CENTERLINE: { name: "Centerline (Yellow)", c3d: "V-ROAD-CNTR", color: "#eab308", visible: true },
      EOP_CURB: { name: "EOP / Curb (Gray)", c3d: "V-ROAD-CURB", color: "#94a3b8", visible: true },
      BUILDING: { name: "Building (Purple)", c3d: "V-BLDG", color: "#a855f7", visible: true },
      UTILITIES: { name: "Utilities / SUE (Blue)", c3d: "V-UTIL-WATR", color: "#0284c7", visible: true },
      FIELD_SKETCHES: { name: "Fence / Sketches (Orange)", c3d: "V-SITE-FENC", color: "#f97316", visible: true },
      POINTS: { name: "Survey Points", c3d: "V-NODE-PNT", color: "#ffffff", visible: true, showLabels: true }
    };
    this.layerModalOpen = false;

    this.linework = [];
    this.touchPinchDist = null;

    if (this.canvas) {
      this.initEvents();
    }
  }

  init(initialLinework) {
    const saved = localStorage.getItem('survey_linework');
    if (saved) {
      try {
        this.linework = JSON.parse(saved);
      } catch (e) {
        this.linework = initialLinework ? [...initialLinework] : [];
      }
    } else {
      this.linework = initialLinework ? [...initialLinework] : [];
    }

    this.resizeCanvas();
    window.addEventListener('resize', () => this.resizeCanvas());

    setTimeout(() => {
      this.fitExtents();
      this.render();
    }, 50);
  }

  save() {
    localStorage.setItem('survey_linework', JSON.stringify(this.linework));
  }

  resizeCanvas() {
    if (!this.canvas) return;
    const rect = this.canvas.parentElement.getBoundingClientRect();
    const dpr = window.devicePixelRatio || 1;

    this.width = rect.width || 800;
    this.height = rect.height || 500;

    this.canvas.width = this.width * dpr;
    this.canvas.height = this.height * dpr;

    this.ctx = this.canvas.getContext('2d');
    this.ctx.scale(dpr, dpr);
    this.render();
  }

  worldToScreen(northing, easting) {
    const screenX = (easting - this.originE) * this.scale + (this.width / 2);
    const screenY = (this.height / 2) - (northing - this.originN) * this.scale;
    return { x: screenX, y: screenY };
  }

  screenToWorld(screenX, screenY) {
    const easting = this.originE + (screenX - (this.width / 2)) / this.scale;
    const northing = this.originN + ((this.height / 2) - screenY) / this.scale;
    return { northing, easting };
  }

  initEvents() {
    this.canvas.addEventListener('mousedown', e => this.handleMouseDown(e));
    this.canvas.addEventListener('mousemove', e => this.handleMouseMove(e));
    this.canvas.addEventListener('mouseup', e => this.handleMouseUp(e));
    this.canvas.addEventListener('wheel', e => this.handleWheel(e), { passive: false });
    this.canvas.addEventListener('dblclick', () => this.finishActiveDrawing());

    this.canvas.addEventListener('touchstart', e => this.handleTouchStart(e), { passive: false });
    this.canvas.addEventListener('touchmove', e => this.handleTouchMove(e), { passive: false });
    this.canvas.addEventListener('touchend', () => this.handleTouchEnd());

    window.addEventListener('keydown', e => {
      if (e.key === 'Escape') this.cancelActiveDrawing();
      if (e.key === 'Enter') this.finishActiveDrawing();
    });
  }

  handleMouseDown(e) {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;

    if (e.button === 1 || this.activeTool === 'pan') {
      this.isPanning = true;
      this.lastMouseX = x;
      this.lastMouseY = y;
      return;
    }

    if (e.button === 0) {
      this.handleAction(x, y);
    }
  }

  handleMouseMove(e) {
    const rect = this.canvas.getBoundingClientRect();
    const x = e.clientX - rect.left;
    const y = e.clientY - rect.top;
    this.cursorScreenX = x;
    this.cursorScreenY = y;

    if (this.isPanning) {
      const dx = x - this.lastMouseX;
      const dy = y - this.lastMouseY;
      this.originE -= dx / this.scale;
      this.originN += dy / this.scale;
      this.lastMouseX = x;
      this.lastMouseY = y;
      this.render();
      return;
    }

    const world = this.screenToWorld(x, y);
    this.mouseWorldN = world.northing;
    this.mouseWorldE = world.easting;

    this.checkSnap(x, y);
    this.updateHUD();
    this.render();
  }

  handleMouseUp() {
    this.isPanning = false;
  }

  handleWheel(e) {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();
    const mx = e.clientX - rect.left;
    const my = e.clientY - rect.top;
    const factor = e.deltaY < 0 ? 1.15 : 0.87;
    this.zoomAt(mx, my, factor);
  }

  handleTouchStart(e) {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();

    if (e.touches.length === 1) {
      const t = e.touches[0];
      const x = t.clientX - rect.left;
      const y = t.clientY - rect.top;
      this.lastMouseX = x;
      this.lastMouseY = y;
      this.cursorScreenX = x;
      this.cursorScreenY = y;

      if (this.activeTool === 'pan') {
        this.isPanning = true;
      } else {
        this.handleAction(x, y);
      }
    } else if (e.touches.length === 2) {
      this.isPanning = false;
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      this.touchPinchDist = Math.hypot(dx, dy);
    }
  }

  handleTouchMove(e) {
    e.preventDefault();
    const rect = this.canvas.getBoundingClientRect();

    if (e.touches.length === 1) {
      const t = e.touches[0];
      const x = t.clientX - rect.left;
      const y = t.clientY - rect.top;
      this.cursorScreenX = x;
      this.cursorScreenY = y;

      if (this.isPanning || this.activeTool === 'pan') {
        const dx = x - this.lastMouseX;
        const dy = y - this.lastMouseY;
        this.originE -= dx / this.scale;
        this.originN += dy / this.scale;
        this.lastMouseX = x;
        this.lastMouseY = y;
        this.render();
      } else {
        const world = this.screenToWorld(x, y);
        this.mouseWorldN = world.northing;
        this.mouseWorldE = world.easting;
        this.checkSnap(x, y);
        this.render();
      }
    } else if (e.touches.length === 2 && this.touchPinchDist) {
      const dx = e.touches[0].clientX - e.touches[1].clientX;
      const dy = e.touches[0].clientY - e.touches[1].clientY;
      const newDist = Math.hypot(dx, dy);
      const factor = newDist / this.touchPinchDist;

      const midX = (e.touches[0].clientX + e.touches[1].clientX) / 2 - rect.left;
      const midY = (e.touches[0].clientY + e.touches[1].clientY) / 2 - rect.top;

      this.zoomAt(midX, midY, factor);
      this.touchPinchDist = newDist;
    }
  }

  handleTouchEnd() {
    this.touchPinchDist = null;
    this.isPanning = false;
  }

  zoomAt(screenX, screenY, factor) {
    const worldBefore = this.screenToWorld(screenX, screenY);
    const newScale = Math.max(this.minScale, Math.min(this.maxScale, this.scale * factor));
    this.scale = newScale;

    const worldAfter = this.screenToWorld(screenX, screenY);
    this.originE += (worldBefore.easting - worldAfter.easting);
    this.originN += (worldBefore.northing - worldAfter.northing);
    this.render();
  }

  checkSnap(screenX, screenY) {
    this.snappedPoint = null;
    if (!window.pointManager) return;

    const points = window.pointManager.getAll();
    let minDist = this.snapRadius;

    for (const pt of points) {
      const sp = this.worldToScreen(pt.northing, pt.easting);
      const dist = Math.hypot(screenX - sp.x, screenY - sp.y);
      if (dist < minDist) {
        minDist = dist;
        this.snappedPoint = pt;
      }
    }
  }

  handleAction(screenX, screenY) {
    let targetN = this.mouseWorldN;
    let targetE = this.mouseWorldE;
    let targetZ = 685.00;
    let pointId = null;

    if (this.snappedPoint) {
      targetN = this.snappedPoint.northing;
      targetE = this.snappedPoint.easting;
      targetZ = this.snappedPoint.elevation;
      pointId = this.snappedPoint.id;
    }

    const vertex = { id: pointId, n: targetN, e: targetE, z: targetZ };

    if (this.activeTool === 'select') {
      if (this.snappedPoint) {
        this.inspectPoint(this.snappedPoint);
      }
    } else if (this.activeTool === 'line') {
      this.activeVertices.push(vertex);
    } else if (this.activeTool === 'point') {
      if (window.app && typeof window.app.openQuickShotModal === 'function') {
        window.app.openQuickShotModal(targetN, targetE, targetZ, 'canvas');
      } else {
        const code = prompt("Enter MAGNET Field Code (e.g. IP FND, EP1 B, CL1, BM):", "IP FND");
        if (code !== null) {
          const desc = prompt("Enter Description / Notes:", "Survey Monument") || "";
          window.pointManager.addPoint({
            northing: targetN,
            easting: targetE,
            elevation: targetZ,
            code: code.toUpperCase(),
            desc
          });
          this.render();
        }
      }
    } else if (this.activeTool === 'measure') {
      this.activeVertices.push(vertex);
      if (this.activeVertices.length === 2) {
        const p1 = this.activeVertices[0];
        const p2 = this.activeVertices[1];
        const inv = PointManager.inverse(p1.n, p1.e, p2.n, p2.e, p1.z, p2.z);
        this.showMeasurePopup(inv);
        this.activeVertices = [];
      }
    }

    this.render();
  }

  finishActiveDrawing() {
    if (this.activeVertices.length >= 2) {
      const feat = this.features[this.currentFeature] || this.features.BOUNDARY;
      const newLine = {
        id: "line-" + Date.now(),
        layer: feat.c3d || this.currentFeature,
        name: `${feat.name} Linework`,
        color: feat.color,
        lineWidth: feat.lineWidth,
        dash: feat.dash || [],
        closed: feat.closed && this.activeVertices.length >= 3,
        points: [...this.activeVertices]
      };

      this.linework.push(newLine);
      this.save();
      if (window.soundFX) window.soundFX.playShotBeep();
      this.activeVertices = [];
      this.render();
      this.renderLayerModal();
    }
  }

  cancelActiveDrawing() {
    this.activeVertices = [];
    this.render();
  }

  setFeature(featureName) {
    if (this.features[featureName]) {
      this.currentFeature = featureName;
      document.querySelectorAll('.survey-feat-btn, .feat-chip, .sue-util-btn').forEach(btn => {
        btn.classList.toggle('active', btn.dataset.feat === featureName);
      });
      const hint = document.getElementById('cad-tool-instruction');
      if (hint && this.activeTool === 'line') {
        hint.textContent = `Drawing ${this.features[featureName].name}. Tap or click points to connect, then click 'Finish'.`;
      }
    }
  }

  setTool(tool) {
    this.cancelActiveDrawing();
    this.activeTool = tool;
    this.canvas.style.cursor = tool === 'pan' ? 'grab' : 'crosshair';

    document.querySelectorAll('.cad-tool-btn, .map-tool-btn, .sue-tool-btn').forEach(btn => {
      btn.classList.toggle('active', btn.dataset.tool === tool);
    });

    const finishBtn = document.getElementById('btn-finish-drawing');
    if (finishBtn) finishBtn.style.display = tool === 'line' ? 'inline-flex' : 'none';

    const featBar = document.getElementById('map-feature-bar');
    if (featBar) featBar.style.display = tool === 'line' ? 'flex' : 'none';

    const hint = document.getElementById('cad-tool-instruction');
    if (hint) {
      const map = {
        select: "Click any survey marker or boundary line to inspect its details.",
        measure: "Click any two points on the map to calculate distance and heading angle.",
        line: `Drawing ${this.features[this.currentFeature]?.name || 'Line'}. Click points to connect, then click 'Finish'.`,
        point: "Click anywhere on the map to place a new coordinate point.",
        pan: "Click and drag to pan across the survey site."
      };
      hint.textContent = map[tool] || "";
    }
  }

  sendLineworkToAim() {
    const count = this.linework.length;
    const bndy = this.linework.filter(l => this.normalizeLayerKey(l.layer) === 'BOUNDARY').length;
    const road = this.linework.filter(l => {
      const k = this.normalizeLayerKey(l.layer);
      return k === 'CENTERLINE' || k === 'EOP_CURB';
    }).length;

    const html = `
      <div class="chat-cogo-badge">
        <span class="badge-tag">📐 MAGNET LINEWORK → CIVIL 3D</span>
        <div>Total Figures: <b>${count}</b> (Boundary: ${bndy}, Road: ${road})</div>
        <div class="badge-coords">Civil 3D Layers: V-PROP-LINE, V-ROAD-CNTR, V-ROAD-CURB, V-BLDG, V-UTIL-WATR</div>
        <span class="badge-link" onclick="window.app.switchTab('cad')">🔍 View on Survey Linework Canvas</span>
      </div>
    `;

    if (window.aimChat) {
      window.aimChat.sendMessage(`Transmitted MAGNET Field Linework (${count} figures) to Civil 3D Office`, html);
      if (window.app && window.app.showToast) {
        window.app.showToast(`Shared ${count} survey figures to Civil 3D Office via AIM!`);
      }
      window.app.switchTab('aim');
    }
  }

  normalizeLayerKey(layerName) {
    if (!layerName) return 'BOUNDARY';
    const up = String(layerName).trim().toUpperCase();
    if (this.layers[up]) return up;
    if (up === 'SKETCH' || up.includes('FENC') || up.includes('SKETCH')) return 'FIELD_SKETCHES';
    if (up.includes('PROP') || up.includes('BND')) return 'BOUNDARY';
    if (up.includes('CNTR') || up.includes('CENTER')) return 'CENTERLINE';
    if (up.includes('CURB') || up.includes('EOP')) return 'EOP_CURB';
    if (up.includes('BLDG') || up.includes('BUILD')) return 'BUILDING';
    if (up.includes('UTIL') || up.includes('WATR') || up.includes('SSWR') || up.includes('STRM')) return 'UTILITIES';
    if (up.includes('NODE') || up.includes('PNT') || up.includes('POINT')) return 'POINTS';
    return 'BOUNDARY';
  }

  toggleLayerModal() {
    this.layerModalOpen = !this.layerModalOpen;
    this.renderLayerModal();
  }

  toggleLayerVisibility(key) {
    if (this.layers[key]) {
      this.layers[key].visible = !this.layers[key].visible;
      this.renderLayerModal();
      this.render();
    }
  }

  renderLayerModal() {
    const el = document.getElementById('cad-layer-modal');
    if (!el) return;
    if (!this.layerModalOpen) {
      el.innerHTML = '';
      return;
    }

    const ptsCount = window.pointManager ? window.pointManager.getAll().length : 0;
    const rows = Object.keys(this.layers).map(key => {
      const lyr = this.layers[key];
      const count = key === 'POINTS'
        ? ptsCount
        : this.linework.filter(l => this.normalizeLayerKey(l.layer) === key).length;
      return `
        <label class="layer-item-row" style="cursor:pointer;">
          <input type="checkbox" ${lyr.visible ? 'checked' : ''} onchange="window.cadEngine.toggleLayerVisibility('${key}')">
          <span class="layer-color-badge" style="background:${lyr.color}"></span>
          <span class="layer-name-label" title="${lyr.c3d}">${lyr.name} <small style="color:#64748b">(${lyr.c3d})</small></span>
          <span class="layer-count-badge">${count}</span>
        </label>
      `;
    }).join('');

    el.innerHTML = `
      <div class="cad-layer-modal-dialog">
        <div class="cad-layer-modal-header">
          <span>🗂️ Civil 3D / MAGNET Layers</span>
          <button class="btn-close" onclick="window.cadEngine.toggleLayerModal()">×</button>
        </div>
        <div class="cad-layer-list">${rows}</div>
        <div class="cad-layer-modal-footer">
          <button class="btn btn-xs btn-outline-warning" onclick="window.dxfManager.exportCivil3dFbk()">📤 Export Civil 3D .FBK</button>
        </div>
      </div>
    `;
  }

  showMeasurePopup(inv) {
    const el = document.getElementById('cad-measure-results');
    if (el) {
      el.innerHTML = `
        <div class="measure-popup">
          <div class="measure-header">
            <span>📐 Distance &amp; Direction</span>
            <button class="btn-close-sm" onclick="document.getElementById('cad-measure-results').innerHTML=''">✕</button>
          </div>
          <div class="measure-body">
            <div class="measure-main-val"><b>${inv.horizDist.toFixed(2)} ft</b> <small style="color:var(--text-muted); font-size:12px;">(${ (inv.horizDist / 3).toFixed(1) } yds)</small></div>
            <div class="measure-row"><span>Quadrant Bearing:</span> <b class="text-accent">${inv.bearing}</b></div>
            <div class="measure-row"><span>Slope Distance:</span> <span>${inv.slopeDist.toFixed(2)} ft</span></div>
            <div class="measure-row"><span>Elevation Delta (ΔZ):</span> <span>${inv.deltaZ >= 0 ? '+' : ''}${inv.deltaZ.toFixed(2)} ft</span></div>
            <div class="measure-row"><span>Grade / Slope:</span> <span>${inv.grade.toFixed(1)}%</span></div>
          </div>
          <div style="display:flex; gap:6px; margin-top:8px;">
            <button class="btn btn-xs btn-outline-light" onclick="document.getElementById('cad-measure-results').innerHTML=''">Clear</button>
            <button class="btn btn-xs btn-primary" style="flex:1;" onclick="window.aimChat.sendInverseToChat('${inv.bearing}', ${inv.horizDist.toFixed(2)}, ${inv.deltaZ.toFixed(2)})">
              💬 Share in Chat
            </button>
          </div>
        </div>
      `;
    }
  }

  inspectPoint(pt) {
    const el = document.getElementById('cad-inspector');
    if (el) {
      let friendlyName = pt.desc || pt.code;
      if (/IP|REBAR|PIN|CORNER|MON/i.test(pt.code)) friendlyName = "Property Corner / Boundary Pin";
      else if (/EP|CURB|EOP/i.test(pt.code)) friendlyName = "Road Edge / Pavement Curb";
      else if (/CL/i.test(pt.code)) friendlyName = "Road Centerline";
      else if (/BLDG/i.test(pt.code)) friendlyName = "Building Footprint Corner";
      else if (/BM/i.test(pt.code)) friendlyName = "Benchmark Elevation Control";
      else if (/UTIL|WM|MH|SAN|WAT/i.test(pt.code)) friendlyName = "Utility Feature";

      el.innerHTML = `
        <div class="inspector-card">
          <div class="inspector-header">
            <div style="display:flex; align-items:center; gap:6px;">
              <span class="badge ${pt.type || 'TOPO'}">PT #${pt.id}</span>
              <span class="inspector-code font-bold">${pt.code}</span>
            </div>
            <button class="btn-close-sm" onclick="document.getElementById('cad-inspector').innerHTML=''">✕</button>
          </div>
          <div style="font-size:12px; color:var(--text-muted); margin: 3px 0 6px 0;">${friendlyName}</div>
          <div class="inspector-grid">
            <div class="insp-item"><span>Northing (Y):</span><b>${pt.northing.toFixed(2)}'</b></div>
            <div class="insp-item"><span>Easting (X):</span><b>${pt.easting.toFixed(2)}'</b></div>
            <div class="insp-item"><span>Elevation (Z):</span><b>${pt.elevation.toFixed(2)}'</b></div>
            <div class="insp-item"><span>Rod Height:</span><span>${pt.hr ? pt.hr.toFixed(2) + "'" : "6.56'"}</span></div>
          </div>
          <div class="inspector-actions">
            <button class="btn btn-xs btn-primary" onclick="window.cadEngine.startMeasureFromPoint(${pt.id})">📐 Measure From Here</button>
            <button class="btn btn-xs btn-secondary" onclick="window.cadEngine.zoomToPoint(${pt.id})">🔍 Zoom</button>
            <button class="btn btn-xs btn-outline-danger" onclick="window.app.deletePoint(${pt.id})">🗑️ Delete</button>
          </div>
        </div>
      `;
    }
  }

  startMeasureFromPoint(ptId) {
    const pt = window.pointManager.getById(ptId);
    if (!pt) return;
    this.setTool('measure');
    this.measureStart = { northing: pt.northing, easting: pt.easting, elevation: pt.elevation, ptId: pt.id };
    const hint = document.getElementById('cad-tool-instruction');
    if (hint) {
      hint.textContent = `Measuring from PT #${pt.id} (${pt.code}). Tap any second point to calculate distance and heading.`;
    }
  }

  fitExtents() {
    let minN = Infinity, maxN = -Infinity, minE = Infinity, maxE = -Infinity;

    if (window.pointManager) {
      window.pointManager.getAll().forEach(p => {
        if (p.northing < minN) minN = p.northing;
        if (p.northing > maxN) maxN = p.northing;
        if (p.easting < minE) minE = p.easting;
        if (p.easting > maxE) maxE = p.easting;
      });
    }

    if (minN === Infinity) {
      this.originN = 10250.0;
      this.originE = 10250.0;
      this.scale = 1.0;
      return;
    }

    this.originN = (minN + maxN) / 2;
    this.originE = (minE + maxE) / 2;

    const pad = 1.35;
    const rangeN = (maxN - minN) || 200;
    const rangeE = (maxE - minE) || 200;

    this.scale = Math.min(this.height / (rangeN * pad), this.width / (rangeE * pad), 3.0);
    this.render();
  }

  zoomToPoint(pointId) {
    const pt = window.pointManager.getById(pointId);
    if (!pt) return;
    this.originN = pt.northing;
    this.originE = pt.easting;
    this.scale = 3.5;
    this.inspectPoint(pt);
    this.render();
  }

  updateHUD() {
    const el = document.getElementById('cad-coord-hud');
    if (el) {
      const snapTag = this.snappedPoint ? ` • SNAP #${this.snappedPoint.id}` : '';
      el.innerHTML = `N: <b>${this.mouseWorldN.toFixed(2)}</b> E: <b>${this.mouseWorldE.toFixed(2)}</b>${snapTag}`;
    }
  }

  render() {
    if (!this.ctx) return;
    const ctx = this.ctx;
    ctx.clearRect(0, 0, this.width, this.height);

    this.drawGrid(ctx);
    this.drawLinework(ctx);
    this.drawActive(ctx);
    this.drawPoints(ctx);

    if (this.snappedPoint) {
      this.drawSnap(ctx, this.snappedPoint);
    }
  }

  drawGrid(ctx) {
    const gridSpacing = this.scale > 1.5 ? 25 : 50;
    const topLeft = this.screenToWorld(0, 0);
    const bottomRight = this.screenToWorld(this.width, this.height);

    const startE = Math.floor(topLeft.easting / gridSpacing) * gridSpacing;
    const endE = Math.ceil(bottomRight.easting / gridSpacing) * gridSpacing;
    const startN = Math.floor(bottomRight.northing / gridSpacing) * gridSpacing;
    const endN = Math.ceil(topLeft.northing / gridSpacing) * gridSpacing;

    ctx.strokeStyle = "rgba(255, 255, 255, 0.05)";
    ctx.lineWidth = 1;
    ctx.beginPath();

    for (let e = startE; e <= endE; e += gridSpacing) {
      const sp = this.worldToScreen(this.originN, e);
      ctx.moveTo(sp.x, 0); ctx.lineTo(sp.x, this.height);
    }
    for (let n = startN; n <= endN; n += gridSpacing) {
      const sp = this.worldToScreen(n, this.originE);
      ctx.moveTo(0, sp.y); ctx.lineTo(this.width, sp.y);
    }
    ctx.stroke();
  }

  drawLinework(ctx) {
    this.linework.forEach(elem => {
      const layerKey = this.normalizeLayerKey(elem.layer);
      if (this.layers[layerKey] && !this.layers[layerKey].visible) return;

      const pts = elem.points;
      if (!pts || pts.length < 2) return;

      ctx.save();
      ctx.strokeStyle = elem.color || (this.layers[layerKey]?.color) || "#ef4444";
      ctx.lineWidth = elem.lineWidth || 2.0;
      if (elem.dash && elem.dash.length > 0) ctx.setLineDash(elem.dash);

      ctx.beginPath();
      const first = this.worldToScreen(pts[0].n, pts[0].e);
      ctx.moveTo(first.x, first.y);

      for (let i = 1; i < pts.length; i++) {
        const sp = this.worldToScreen(pts[i].n, pts[i].e);
        ctx.lineTo(sp.x, sp.y);
      }

      if (elem.closed) {
        ctx.closePath();
        ctx.fillStyle = elem.color ? elem.color + "18" : "#ffffff18";
        ctx.fill();
      }

      ctx.stroke();

      // Show distance on segments if zoomed
      if (this.scale > 0.45 && pts.length >= 2) {
        const p1 = pts[0];
        const p2 = pts[1];
        const sp = this.worldToScreen((p1.n + p2.n) / 2, (p1.e + p2.e) / 2);
        const dist = Math.hypot(p2.n - p1.n, p2.e - p1.e);

        ctx.fillStyle = "#ffffff";
        ctx.font = "bold 9px 'Roboto Mono', monospace";
        ctx.fillText(`${elem.name || 'LINE'} (${dist.toFixed(1)}')`, sp.x + 4, sp.y - 4);
      }

      ctx.restore();
    });
  }

  drawActive(ctx) {
    if (this.activeVertices.length === 0) return;

    ctx.save();
    const feat = this.features[this.currentFeature] || this.features.BOUNDARY;
    ctx.strokeStyle = feat.color;
    ctx.lineWidth = 2.0;
    ctx.setLineDash([6, 3]);

    ctx.beginPath();
    const first = this.worldToScreen(this.activeVertices[0].n, this.activeVertices[0].e);
    ctx.moveTo(first.x, first.y);

    for (let i = 1; i < this.activeVertices.length; i++) {
      const sp = this.worldToScreen(this.activeVertices[i].n, this.activeVertices[i].e);
      ctx.lineTo(sp.x, sp.y);
    }

    ctx.lineTo(this.cursorScreenX, this.cursorScreenY);
    ctx.stroke();

    ctx.restore();
  }

  drawPoints(ctx) {
    if (!window.pointManager) return;
    if (this.layers.POINTS && !this.layers.POINTS.visible) return;
    const points = window.pointManager.getAll();

    points.forEach(pt => {
      const sp = this.worldToScreen(pt.northing, pt.easting);
      if (sp.x < -20 || sp.x > this.width + 20 || sp.y < -20 || sp.y > this.height + 20) return;

      ctx.save();

      if (pt.type === 'BNDY') {
        // Red circle with cross for boundary corners
        ctx.strokeStyle = "#ef4444";
        ctx.fillStyle = "#ef4444";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.arc(sp.x, sp.y, 4, 0, 2 * Math.PI);
        ctx.stroke();
      } else if (pt.type === 'CTRL') {
        // Amber triangle for traverse control
        ctx.strokeStyle = "#f59e0b";
        ctx.lineWidth = 1.5;
        ctx.beginPath();
        ctx.moveTo(sp.x, sp.y - 5);
        ctx.lineTo(sp.x + 4, sp.y + 4);
        ctx.lineTo(sp.x - 4, sp.y + 4);
        ctx.closePath();
        ctx.stroke();
      } else if (pt.type === 'BM') {
        // Green square for benchmark
        ctx.strokeStyle = "#10b981";
        ctx.lineWidth = 1.5;
        ctx.strokeRect(sp.x - 4, sp.y - 4, 8, 8);
      } else {
        // Standard survey cross
        ctx.strokeStyle = "#38bdf8";
        ctx.lineWidth = 1.2;
        ctx.beginPath();
        ctx.moveTo(sp.x - 3, sp.y - 3); ctx.lineTo(sp.x + 3, sp.y + 3);
        ctx.moveTo(sp.x - 3, sp.y + 3); ctx.lineTo(sp.x + 3, sp.y - 3);
        ctx.stroke();
      }

      ctx.fillStyle = "#ffffff";
      ctx.font = "9px 'Roboto Mono', monospace";
      ctx.fillText(`${pt.code}`, sp.x + 6, sp.y - 3);

      ctx.restore();
    });
  }

  drawSnap(ctx, pt) {
    const sp = this.worldToScreen(pt.northing, pt.easting);
    ctx.save();
    ctx.strokeStyle = "#f59e0b";
    ctx.lineWidth = 2;
    ctx.strokeRect(sp.x - 7, sp.y - 7, 14, 14);

    ctx.fillStyle = "rgba(15, 23, 42, 0.9)";
    ctx.fillRect(sp.x + 10, sp.y - 12, 110, 24);
    ctx.fillStyle = "#ffffff";
    ctx.font = "bold 9px sans-serif";
    ctx.fillText(`PT #${pt.id} (${pt.code})`, sp.x + 14, sp.y + 4);
    ctx.restore();
  }

  // ─────────────────────────────────────────────────────────────────────────────
  // MAGNET Field Linework Code Auto-Builder
  // Parses standard MAGNET Field / Topcon / Sokkia field coding conventions
  // and converts them to Civil 3D-compatible linework layers automatically.
  //
  // MAGNET Field Feature Code Conventions (supported):
  //   EP1 B  or  EP1+   → Begin new string "EP1"
  //   EP1 E  or  EP1-   → End string "EP1"
  //   EP1    or  EP1 C  → Continue string "EP1"
  //   BC     → Begin Curve
  //   EC     → End Curve
  //   PCT    → Point on Curve (no special rendering needed here)
  //
  // Civil 3D Layer Mapping:
  //   EP, EOP, ETP, FL → V-ROAD-CURB   (Edge of Pavement / Curb)
  //   CL, TC, TS       → V-ROAD-CNTR   (Centerline)
  //   IP, BND, LOT, PROP, ROW → V-PROP-LINE (Boundary / Property Line)
  //   BLD, BLDG, FFE   → V-BLDG        (Building Footprint)
  //   WM, WV, GV, SS, MH → V-UTIL-WATR (Utilities)
  //   TBR, TREE, BUSH  → V-SURV-TOPO   (Topo / Vegetation)
  //   BM, TBM, CP      → V-NODE-PNT    (Control / Bench Marks)
  // ─────────────────────────────────────────────────────────────────────────────
  static magnetCodeToLayer(code) {
    if (!code) return 'BOUNDARY';
    const upper = code.trim().toUpperCase().replace(/[+\-]$/, '');
    const tokens = upper.split(/\s+/);
    const c = (tokens[0] === 'B' || tokens[0] === 'E' || tokens[0] === 'C' || tokens[0] === 'CLS') && tokens[1]
      ? tokens[1]
      : tokens[0];

    if (/^(EP|EOP|ETP|FL|CURB|GUTTR)/.test(c)) return 'EOP_CURB';
    if (/^(CL\d*|TC\d*|TS\d*|CNTR|CNTRL)/.test(c)) return 'CENTERLINE';
    if (/^(IP|BND|LOT|PROP|ROW|CORNER|WALL)/.test(c)) return 'BOUNDARY';
    if (/^(FENCE|FNC|GATE)/.test(c)) return 'FIELD_SKETCHES';
    if (/^(BLD|BLDG|FFE|STRUC)/.test(c)) return 'BUILDING';
    if (/^(WM|WV|GV|SS|MH\d*|CO|CB|FH|WTR|GAS|SEWR|STRM|OH|UNK)/.test(c)) return 'UTILITIES';
    return 'BOUNDARY';
  }

  // Build linework automatically from an array of survey points with MAGNET Field codes
  // Supports suffix ("EP1 B", "EP1 E", "EP1+", "EP1-", "BLDG1 CLS") and prefix ("B EP1", "E EP1")
  buildLineworkFromMagnetCodes(points) {
    // Replace any prior auto-generated MAGNET strings so re-running stays clean
    this.linework = this.linework.filter(l => !String(l.id || '').startsWith('magnet-'));

    const strings = {};
    const addedCount = { lines: 0 };

    const commitString = (stringName, s, forceClose = false) => {
      if (!s || s.vertices.length < 2) return;
      const feat = this.features[s.layer] || this.features.BOUNDARY;
      const shouldClose = forceClose || s.closed || (s.layer === 'BUILDING' && s.vertices.length >= 3);
      this.linework.push({
        id: `magnet-${stringName}-${Date.now()}-${addedCount.lines}`,
        layer: feat.c3d || s.layer,
        name: `MAGNET ${stringName}`,
        color: feat.color,
        lineWidth: feat.lineWidth,
        dash: feat.dash || [],
        closed: shouldClose,
        points: [...s.vertices]
      });
      addedCount.lines++;
    };

    points.forEach(pt => {
      const rawCode = (pt.code || '').trim();
      if (!rawCode) return;

      const isPlus = rawCode.endsWith('+');
      const isMinus = rawCode.endsWith('-');
      const cleaned = rawCode.replace(/[+\-]$/, '').trim().toUpperCase();
      const tokens = cleaned.split(/\s+/).filter(Boolean);
      if (tokens.length === 0) return;

      // Pure curve keywords without string tag
      if (tokens.length === 1 && (tokens[0] === 'BC' || tokens[0] === 'EC' || tokens[0] === 'PCT')) return;

      let isBegin = isPlus;
      let isEnd = isMinus;
      let isClose = false;
      let stringTokens = [...tokens];

      // Check suffix action
      const last = stringTokens[stringTokens.length - 1];
      if (stringTokens.length > 1 && /^(B|E|C|CLS|CLOSE)$/.test(last)) {
        if (last === 'B') isBegin = true;
        if (last === 'E') isEnd = true;
        if (last === 'CLS' || last === 'CLOSE') { isEnd = true; isClose = true; }
        stringTokens.pop();
      } else if (stringTokens.length > 1 && /^(B|E|C|CLS)$/.test(stringTokens[0])) {
        // Check prefix action
        const first = stringTokens.shift();
        if (first === 'B') isBegin = true;
        if (first === 'E') isEnd = true;
        if (first === 'CLS') { isEnd = true; isClose = true; }
      }

      // Remove inline BC/EC curve modifiers while preserving string name
      stringTokens = stringTokens.filter(t => t !== 'BC' && t !== 'EC' && t !== 'PCT');
      const stringName = stringTokens.join(' ').trim();
      if (!stringName) return;

      // Skip isolated monument/control/point-only codes unless explicitly given B/E
      if (!isBegin && !isEnd && /^(CP\d*|BM-?\d*|IP\b|FFE|WM|WV|FH|TREE)/.test(stringName)) {
        return;
      }

      const layer = CadEngine.magnetCodeToLayer(stringName);
      const vertex = { id: pt.id, n: pt.northing, e: pt.easting, z: pt.elevation };

      if (isBegin || !strings[stringName]) {
        if (isBegin && strings[stringName] && strings[stringName].vertices.length >= 2) {
          commitString(stringName, strings[stringName], false);
        }
        strings[stringName] = { vertices: [vertex], layer, closed: isClose };
      } else {
        strings[stringName].vertices.push(vertex);
        if (isClose) strings[stringName].closed = true;
      }

      if (isEnd && strings[stringName] && strings[stringName].vertices.length >= 2) {
        commitString(stringName, strings[stringName], isClose);
        delete strings[stringName];
      }
    });

    Object.keys(strings).forEach(sn => {
      commitString(sn, strings[sn], strings[sn].closed);
    });

    this.save();
    this.render();
    this.renderLayerModal();

    const msg = `🗺️ MAGNET Field auto-linework: ${addedCount.lines} Civil 3D figures built from ${points.length} coded points (V-PROP-LINE, V-ROAD-CNTR, V-ROAD-CURB, V-BLDG, V-SITE-FENC).`;
    if (window.aimChat) window.aimChat.postSystemUpdate(msg);
    return addedCount.lines;
  }

  // Build linework from currently loaded points using their field codes
  buildLineworkFromCurrentPoints() {
    if (!window.pointManager) return 0;
    const points = window.pointManager.getAll();
    return this.buildLineworkFromMagnetCodes(points);
  }
}

window.CadEngine = CadEngine;
