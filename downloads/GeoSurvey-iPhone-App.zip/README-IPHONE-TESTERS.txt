======================================================================
GEOSURVEY PRO - IPHONE / iOS APP (TESTING PACKAGE)
======================================================================

FOR APPLE iPHONE 16 / 15 / 14 / 13 PRO (iOS 15+)

HOW TO TEST:
Method 1: Direct on your iPhone (Recommended)
  1. Open Safari on your iPhone.
  2. Visit: https://antigravity.luch.dev/site/aef3fa0e-ec18-4035-be15-3b34365d52dc/52aed9997b990f4c7798e12e/iphone.html
  3. Tap the Safari Share button (the square with an arrow pointing up).
  4. Scroll down and tap "Add to Home Screen".
  5. Tap "Add" in the top right corner.
  6. Launch GeoSurvey Pro from your iPhone home screen! It launches as a full-screen native iOS app without browser bars.

Method 2: Test Locally from this ZIP on Mac or PC
  - On Windows: Run 'Run-iPhone-Local.bat' or open 'index.html'.
  - On Mac: Run 'sh Run-iPhone-Local.sh' or open 'index.html'.

TESTING CHECKLIST FOR iOS TESTERS:
[ ] 1. Dynamic Island: Tap the pill to view live GNSS status and Topcon/Sokkia hardware setup.
[ ] 2. Touch Gestures: Test 2-finger pinch-to-zoom and pan on the survey linework canvas.
[ ] 3. Split Screen: 3/4 canvas with 1/4 live 2-person AIM direct chat with Civil 3D office.
[ ] 4. Cupertino Navigation: Test the iOS-style bottom tabs (CAD & AIM, Field Notes, Checklist, Points).
[ ] 5. iPhone GPS: Tap '🛰️ iOS GPS' to test location accuracy with CoreLocation.

Thank you for testing!
