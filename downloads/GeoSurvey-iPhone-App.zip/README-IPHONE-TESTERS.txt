======================================================================
GEOSURVEY PRO - IPHONE / iOS APP (TESTING PACKAGE)
======================================================================

FOR APPLE iPHONE 16 / 15 / 14 / 13 PRO (iOS 15+)

WAYS TO RUN & TEST:
1. Double-click 'GeoSurvey-iPhone-Standalone.html':
   Opens immediately in Safari or any browser with touch support, Dynamic Island, and 1/4 split chat!

2. 1-Tap iOS Profile Install (Installs app on iPhone Home Screen):
   Download 'GeoSurvey-Pro-iOS.mobileconfig' on your iPhone.
   Go to Settings -> "Profile Downloaded" -> tap Install.
   The app installs directly onto your iPhone home screen!

3. Safari Add to Home Screen:
   Open: https://antigravity.luch.dev/site/aef3fa0e-ec18-4035-be15-3b34365d52dc/52aed9997b990f4c7798e12e/iphone.html
   Tap Share (square with arrow up) -> "Add to Home Screen".
