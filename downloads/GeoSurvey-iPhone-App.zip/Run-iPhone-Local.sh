#!/bin/bash
echo "Starting GeoSurvey Pro iPhone iOS App on http://localhost:8081..."
python3 -m http.server 8081 &
PID=
sleep 1
if which open > /dev/null; then open http://localhost:8081/; elif which xdg-open > /dev/null; then xdg-open http://localhost:8081/; fi
wait 
