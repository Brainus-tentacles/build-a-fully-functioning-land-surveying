#!/bin/bash
echo "Starting GeoSurvey Pro iPhone iOS App..."
if [ -f "GeoSurvey-iPhone-Standalone.html" ]; then
    TARGET="GeoSurvey-iPhone-Standalone.html"
else
    TARGET="index.html"
fi
if which open > /dev/null 2>&1; then
    open "$TARGET"
elif which xdg-open > /dev/null 2>&1; then
    xdg-open "$TARGET"
fi
