@echo off
title GeoSurvey Pro - iPhone iOS App
echo Starting GeoSurvey Pro iPhone Edition...
if exist "GeoSurvey-iPhone-Standalone.html" (
    start "" "GeoSurvey-iPhone-Standalone.html"
) else (
    start "" "index.html"
)
