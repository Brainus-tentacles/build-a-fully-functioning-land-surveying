@echo off
title GeoSurvey Pro - iPhone iOS App
echo Starting GeoSurvey Pro iPhone Edition...
python -m http.server 8081 || py -m http.server 8081
start http://localhost:8081/
pause
