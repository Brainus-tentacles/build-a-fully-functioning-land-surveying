======================================================================
GEOSURVEY CIVIL 3D OFFICE WORKSTATION - COMPUTER PROGRAM
======================================================================

FOR CAD DRAFTERS & OFFICE SURVEYORS (WINDOWS & MAC)

WAYS TO RUN & TEST:
1. Double-click 'GeoSurvey-Civil3D-Workstation.hta' (Native Windows App):
   Immediately launches as a native desktop application window with no browser URL bar!

2. Double-click 'Launch-Civil3D-Desktop.vbs' or 'Start-Civil3D-Workstation.bat':
   Opens Civil 3D workstation in standalone desktop application window mode.

3. Double-click 'GeoSurvey-Civil3D-Standalone.html':
   Self-contained single-file software that runs immediately on any PC or Mac!

4. Mac / Linux:
   Run 'sh Start-Civil3D-Workstation.sh' or double-click 'GeoSurvey-Civil3D-Standalone.html'.
