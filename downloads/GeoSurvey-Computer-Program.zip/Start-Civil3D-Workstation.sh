#!/bin/bash
echo "Starting GeoSurvey Civil 3D Office Workstation..."
DIR="$(cd "$(dirname "$0")" && pwd)"
TARGET="$DIR/GeoSurvey-Civil3D-Standalone.html"
if which google-chrome > /dev/null 2>&1; then
    google-chrome --app="file://$TARGET" &
elif which open > /dev/null 2>&1; then
    open "$TARGET"
elif which xdg-open > /dev/null 2>&1; then
    xdg-open "$TARGET"
fi
