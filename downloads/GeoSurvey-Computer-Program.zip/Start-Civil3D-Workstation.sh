#!/bin/bash
echo "Starting GeoSurvey Civil 3D Office Workstation Computer Program on http://localhost:8082..."
PORT=8082
python3 -m http.server  &
PID=
sleep 1
if which google-chrome > /dev/null; then
  google-chrome --app="http://localhost:/" &
elif which open > /dev/null; then
  open "http://localhost:/"
elif which xdg-open > /dev/null; then
  xdg-open "http://localhost:/"
fi
wait 
