#!/bin/bash
echo "======================================================================"
echo "Starting GeoSurvey Civil 3D Office Workstation Computer Program..."
echo "======================================================================"
PORT=8082
python3 -m http.server  &
PID=
sleep 1

# Try Chrome or default browser in app mode
if which google-chrome > /dev/null; then
  google-chrome --app="http://localhost:/" &
elif which open > /dev/null; then
  open -a "Google Chrome" --args --app="http://localhost:/" 2>/dev/null || open "http://localhost:/"
elif which xdg-open > /dev/null; then
  xdg-open "http://localhost:/"
fi

echo "Workstation running on PID . Press Ctrl+C to terminate."
wait 
