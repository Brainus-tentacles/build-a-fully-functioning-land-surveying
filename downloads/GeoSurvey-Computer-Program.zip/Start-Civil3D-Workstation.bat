@echo off
title Autodesk Civil 3D 2026 - GeoSurvey Workstation Launcher
echo Starting GeoSurvey Civil 3D Office Workstation...
set HTML_FILE="%~dp0GeoSurvey-Civil3D-Standalone.html"

if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    start "" "%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app="file:///%HTML_FILE:\=/%"
    exit
)
if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    start "" "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app="file:///%HTML_FILE:\=/%"
    exit
)
start "" %HTML_FILE%
