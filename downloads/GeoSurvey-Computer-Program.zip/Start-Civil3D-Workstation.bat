@echo off
title Autodesk Civil 3D 2026 - GeoSurvey Workstation Launcher
echo ======================================================================
echo Launching GeoSurvey Civil 3D Workstation Computer Program...
echo ======================================================================

set PORT=8082

:: Check for Chrome or Edge to run in true native standalone application window mode
set BROWSER_CMD=""
if exist "%ProgramFiles%\Google\Chrome\Application\chrome.exe" (
    set BROWSER_CMD="%ProgramFiles%\Google\Chrome\Application\chrome.exe" --app=http://localhost:%PORT%/
) else if exist "%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" (
    set BROWSER_CMD="%ProgramFiles(x86)%\Google\Chrome\Application\chrome.exe" --app=http://localhost:%PORT%/
) else if exist "%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" (
    set BROWSER_CMD="%ProgramFiles(x86)%\Microsoft\Edge\Application\msedge.exe" --app=http://localhost:%PORT%/
)

:: Start background server and launch app window
start "" /B python -m http.server %PORT% 2>nul || start "" /B py -m http.server %PORT% 2>nul
timeout /t 1 /nobreak >nul

if not %BROWSER_CMD%=="" (
    start "" %BROWSER_CMD%
) else (
    start http://localhost:%PORT%/
)

echo Civil 3D Program is running at http://localhost:%PORT%/
echo Press any key to stop the workstation server.
pause >nul
